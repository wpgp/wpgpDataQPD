

class wpException(Exception):
    """ An exception class to handle wp exceptions"""
    pass
